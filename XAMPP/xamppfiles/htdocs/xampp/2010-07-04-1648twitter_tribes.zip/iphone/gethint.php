<?php

$username=$_GET["username"];
$password=$_GET["password"];
$update_url = "http://twitter.com/statuses/update.xml"; 

$message=" ";
 
 $ch = curl_init($update_url);  
   
     curl_setopt($ch, CURLOPT_POST, 1);  
     curl_setopt($ch, CURLOPT_POSTFIELDS, 'status='.urlencode($message));  
     curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  
     curl_setopt($ch, CURLOPT_USERPWD, $username . ':' . $password);  
   
     curl_exec($ch);  

     $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE); 
	 
	 
	 
if ($httpcode == '200')    
  {
  $response="Correct Username/Password";
  }
else
  {
  $response="Wrong Username/Password";
  }

echo $response;
?>