<?php
 $update_url = "http://twitter.com/statuses/update.xml"; 
 $username=$_GET["username"];
 $password=$_GET["password"];
 $message=$_GET["message"];
 $ch = curl_init($update_url);  
   
     curl_setopt($ch, CURLOPT_POST, 1);  
     curl_setopt($ch, CURLOPT_POSTFIELDS, 'status='.$message);  
     curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  
     curl_setopt($ch, CURLOPT_USERPWD, $username . ':' . $password);  
   
     curl_exec($ch);  

     $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);  
   
     if ($httpcode == '200')  
     {  
	   Echo "Message Sent";
     }  
   
     else  
     { 

        Echo "Status message should be between 0 to 140 characters";
      }
   
?>